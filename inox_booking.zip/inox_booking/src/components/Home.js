import React, { useEffect, useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import './css/home.css';
import Navbar from './Navbar';

const Home = () => {
  const location = useLocation();
  const [user, setUser] = useState({ username: '', email: '', pno: '' });
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    const locationUser = location.state;
    if (locationUser) {
      setUser(locationUser);
      localStorage.setItem('user', JSON.stringify(locationUser));
    } else {
      const storedUser = JSON.parse(localStorage.getItem('user'));
      if (storedUser) setUser(storedUser);
    }

    fetch('http://localhost:8080/movies')
      .then((res) => res.json())
      .then((data) => setMovies(data))
      .catch((err) => console.error('Error fetching movies:', err));
  }, [location.state]);

  const offers = [
    {
      title: 'Amex Platinum & Centurion - Buy 1 Get 1',
      description: 'Offer on minimum purchase of 2 tickets. American Express Platinum Card & Centurion Card only. Valid till: Sun, Aug 31, 2025',
      image: 'https://via.placeholder.com/300x200?text=Buy+1+Get+1',
    },
    {
      title: 'AU Credit Cards - 20% off on Movie Ticket',
      description: 'Valid till: Mon, Jun 30, 2025',
      image: 'https://via.placeholder.com/300x200?text=20%25+Off',
    },
    {
      title: 'Axis Bank Business Supreme Debit Card - Buy 1 Get 1',
      description: 'Valid till: Mon, Jun 30, 2025',
      image: 'https://via.placeholder.com/300x200?text=Buy+1+Get+1+Axis',
    },
    {
      title: 'Axis Bank Prestige Debit Card - Buy One Get One at INOX',
      description: 'Valid till: Mon, Jun 30, 2025',
      image: 'https://via.placeholder.com/300x200?text=Buy+One+Get+One',
    },
  ];

  return (
    <div className="home-container">
      <Navbar username={user.username} />
      <header className="banner">
        <div className="banner-overlay">
          <div className="banner-content">
            <p className="banner-tag">Exclusive Premium Experience</p>
            <h1 className="banner-title">Welcome to INOX Movie Booking</h1>
            <p className="banner-details">Book your tickets now</p>
            <p className="banner-description">
              Jake Sully lives with his newfound family on Pandora. A familiar threat returns to finish what was started.
            </p>
            <p className="banner-director">Director: James Cameron</p>
            <div className="banner-actions">
            </div>
          </div>
        </div>
        <img src="https://wallpapers.com/images/featured/tenet-tu1b44axi1ewo7ya.jpg" alt="Banner" />
      </header>

      <section className="user-profile">
        <div className="profile-card">
          <h2 className="profile-title">Welcome, {user.username || 'Guest'}</h2>
          <div className="profile-details">
            <p>Email: <span>{user.email || 'N/A'}</span></p>
            <p>Phone: <span>{user.phno || 'N/A'}</span></p>
          </div>
        </div>
      </section>

      
      <hr />
      <section className="movies-section">
        <h2 className="section-title">Available Movies</h2>
        <div className="movie-grid">
          {movies.map((movie, index) => (
            <div key={index} className="movie-card">
              <img src={movie.img} alt={movie.title} />
              <div className="movie-info">
                <h3>{movie.title}</h3>
                <p>
                  {movie.genre} {movie.stime ? `| Showtime: ${movie.stime}` : ''}
                </p>
                <Link to="/book" state={{ movie }}>
                  <button className="book-button">Book</button>
                </Link>
              </div>
            </div>
          ))}
        </div>
        <a href="#view-all" className="view-all">View All</a>
      </section>


     <section className="movies-section">
  <h2 className="section-title">Coming Soon</h2>
  <div className="movie-grid">
    <div className="movie-card">
      <img src="https://i.pinimg.com/736x/89/5d/24/895d2482fd516e809023ef09d599769f.jpg" alt="Movie 1" />
      <div className="movie-info">
        <h3>THE Legend</h3>
        <p>Action</p>
        <button className="book-button">Coming Soon</button>
      </div>
    </div>
    <div className="movie-card">
      <img src="https://i.pinimg.com/736x/89/5d/24/895d2482fd516e809023ef09d599769f.jpg" alt="Movie 2" />
      <div className="movie-info">
        <h3>THE Legend</h3>
        <p>Action</p>
        <button className="book-button">Coming Soon</button>
      </div>
    </div>
    <div className="movie-card">
      <img src="https://i.pinimg.com/736x/89/5d/24/895d2482fd516e809023ef09d599769f.jpg" alt="Movie 2" />
      <div className="movie-info">
        <h3>THE Legend</h3>
        <p>Action</p>
        <button className="book-button">Coming Soon</button>
      </div>
    </div>
    <div className="movie-card">
      <img src="https://i.pinimg.com/736x/89/5d/24/895d2482fd516e809023ef09d599769f.jpg" alt="Movie 2" />
      <div className="movie-info">
        <h3>THE Legend</h3>
        <p>Action</p>
        <button className="book-button">Coming Soon</button>
      </div>
    </div>
    <div className="movie-card">
      <img src="https://i.pinimg.com/736x/89/5d/24/895d2482fd516e809023ef09d599769f.jpg" alt="Movie 2" />
      <div className="movie-info">
        <h3>THE Legend</h3>
        <p>Action</p>
        <button className="book-button">Coming Soon</button>
      </div>
    </div>
  </div>
</section>

<section className="coupon-section">
        <h2 className="section-title">Offers For You</h2>
        <div className="offers-grid">
          {offers.map((offer, index) => (
            <div key={index} className="offer-card">
              <img src={offer.image} alt={offer.title} />
              <div className="offer-info">
                <h3>{offer.title}</h3>
                <p>{offer.description}</p>
                <button className="view-button">View</button>
              </div>
            </div>
          ))}
        </div>
      </section>


    </div>
  );
};

export default Home;
