import React, { useEffect, useState, useRef } from "react";
import axios from "axios";
import { useLocation } from "react-router-dom";
import "./css/book.css";
import { useReactToPrint } from "react-to-print";

const Book = () => {
  const location = useLocation();
  const { movie } = location.state || {};
  const [seats, setSeats] = useState([]);
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [userName, setUserName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [showReceipt, setShowReceipt] = useState(false);
  const [bookingDetails, setBookingDetails] = useState(null);
  const [bookingId, setBookingId] = useState("");
  
  // Create a ref for the printable receipt content
  const receiptRef = useRef(null);

  const columns = 4;
  const rows = 4;

  // Function to generate a booking ID
  const generateBookingId = () => {
    const timestamp = new Date().getTime();
    const random = Math.floor(Math.random() * 1000);
    return `BKG-${timestamp}-${random}`;
  };

  // Setup print functionality with safeguard
  const handlePrint = useReactToPrint({
    content: () => {
      if (!receiptRef.current) {
        console.error("Receipt content is not available for printing");
        return null;
      }
      return receiptRef.current;
    },
    documentTitle: `Movie_Ticket_${bookingId}`,
  });

  // Optionally trigger print automatically when receipt modal is shown
  useEffect(() => {
    if (showReceipt && bookingDetails && receiptRef.current) {
      handlePrint();
    }
  }, [showReceipt, bookingDetails, handlePrint]);

  useEffect(() => {
    if (movie && movie.title) {
      axios
        .get(`http://localhost:8080/seats?moviename=${encodeURIComponent(movie.title)}`)
        .then((response) => {
          const updatedSeats = response.data.map((seat) => ({
            ...seat,
            available: seat.available === true || seat.available === "true",
          }));
          setSeats(updatedSeats);
        })
        .catch((error) => {
          console.error("Error fetching seats:", error);
          alert("Failed to load seat data.");
        });
    }
  }, [movie]);

  const maxSeats = rows * columns;
  const seatsToDisplay = seats.slice(0, maxSeats);

  const seatMatrix = Array.from({ length: rows }, (_, rowIndex) => {
    return Array.from({ length: columns }, (_, colIndex) => {
      const seatIndex = rowIndex * columns + colIndex;
      return seatsToDisplay[seatIndex] || null;
    });
  });

  const columnLabels = Array.from({ length: columns }, (_, index) =>
    String.fromCharCode(65 + index)
  );

  const handleBooking = () => {
    if (!userName || !phoneNumber) {
      alert("Please enter your name and phone number.");
      return;
    }

    // Generate a booking ID
    const newBookingId = generateBookingId();
    setBookingId(newBookingId);

    const currentDate = new Date();
    const formattedDate = currentDate.toISOString().split("T")[0];
    const bookingTime = currentDate.toLocaleTimeString();

    const bookingData = {
      uname: userName,
      movie: movie.title,
      time: movie.stime,
      tprice: selectedSeats.length * 100,
      sno: selectedSeats.join(", "),
      pno: phoneNumber,
      date: formattedDate,
    };

    // Store booking details for receipt
    setBookingDetails({
      id: newBookingId,
      ...bookingData,
      hallName: movie.hallname,
      bookingTime: bookingTime,
      genre: movie.genre,
    });

    axios
      .post("http://localhost:8080/bookings", bookingData)
      .then(() => {
        return Promise.all(
          selectedSeats.map((seatno) => {
            const seat = seats.find((seat) => seat.seatno === seatno);
            if (seat) {
              return axios.put(`http://localhost:8080/seats/${seat.id}`, {
                ...seat,
                available: false
              });
            }
            return null;
          })
        );
      })
      .then(() => {
        // Show receipt instead of alert
        setShowReceipt(true);

        // Refresh the seat data after booking
        return axios.get(`http://localhost:8080/seats?moviename=${encodeURIComponent(movie.title)}`);
      })
      .then((response) => {
        const updatedSeats = response.data.map((seat) => ({
          ...seat,
          available: seat.available === true || seat.available === "true",
        }));
        setSeats(updatedSeats);
      })
      .catch((err) => {
        console.error("Booking failed:", err);
        alert("Booking failed. Please try again.");
      });
  };

  const toggleSeatSelection = (seat) => {
    if (!seat.available) return;

    if (selectedSeats.includes(seat.seatno)) {
      setSelectedSeats(selectedSeats.filter((seatno) => seatno !== seat.seatno));
    } else {
      setSelectedSeats([...selectedSeats, seat.seatno]);
    }
  };

  const closeReceipt = () => {
    setShowReceipt(false);
    setSelectedSeats([]);
    setUserName("");
    setPhoneNumber("");
  };

  return (
    <div className="book-container">
      {/* Receipt Modal */}
      {showReceipt && bookingDetails && (
        <div className="receipt-overlay">
          <div className="receipt-container">
            {/* Printable content with ref */}
            <div className="receipt" ref={receiptRef}>
              <div className="receipt-header">
                <h2>Movie Ticket Receipt</h2>
                <div className="booking-id">Booking ID: {bookingDetails.id}</div>
              </div>
              
              <div className="receipt-details">
                <div className="receipt-row">
                  <span className="label">Movie:</span>
                  <span className="value">{bookingDetails.movie}</span>
                </div>
                <div className="receipt-row">
                  <span className="label">Genre:</span>
                  <span className="value">{bookingDetails.genre}</span>
                </div>
                <div className="receipt-row">
                  <span className="label">Show Time:</span>
                  <span className="value">{bookingDetails.time}</span>
                </div>
                <div className="receipt-row">
                  <span className="label">Hall:</span>
                  <span className="value">{bookingDetails.hallName}</span>
                </div>
                <div className="receipt-row">
                  <span className="label">Seat(s):</span>
                  <span className="value">{bookingDetails.sno}</span>
                </div>
                <div className="receipt-row">
                  <span className="label">Customer:</span>
                  <span className="value">{bookingDetails.uname}</span>
                </div>
                <div className="receipt-row">
                  <span className="label">Phone:</span>
                  <span className="value">{bookingDetails.pno}</span>
                </div>
                <div className="receipt-row">
                  <span className="label">Date:</span>
                  <span className="value">{bookingDetails.date}</span>
                </div>
                <div className="receipt-row">
                  <span className="label">Booking Time:</span>
                  <span className="value">{bookingDetails.bookingTime}</span>
                </div>
                <div className="receipt-row total">
                  <span className="label">Total Price:</span>
                  <span className="value">₹{bookingDetails.tprice}</span>
                </div>
              </div>
              
              <div className="receipt-footer">
                <p>Thank you for your booking!</p>
                <p>Please arrive 15 minutes before showtime.</p>
                <p>This ticket is non-refundable and non-transferable.</p>
              </div>
            </div>
            
            <div className="receipt-actions">
              <button
                onClick={handlePrint}
                className="download-btn"
                disabled={!receiptRef.current}
              >
                Download Receipt
              </button>
              <button onClick={closeReceipt} className="close-btn">
                Close
              </button>
            </div>
          </div>
        </div>
      )}
      
      {movie ? (
        <div className="movie-details">
          <h1 className="movie-title">Movie Name: {movie.title}</h1>
          <p><strong>Genre:</strong> {movie.genre}</p>
          <p><strong>Showtime:</strong> {movie.stime}</p>
          <p><strong>Hall Name:</strong> {movie.hallname}</p>

          <h2 className="seat-heading">Available Seats</h2>
          <div className="seat-matrix-container">
            <div className="column-labels">
              <div className="row-label-placeholder"></div>
              {columnLabels.map((label, index) => (
                <div key={index} className="column-label">
                  {label}
                </div>
              ))}
            </div>

            {seatMatrix.length > 0 ? (
              seatMatrix.map((row, rowIndex) => (
                <div key={rowIndex} className="seat-row">
                  <div className="row-label">{rowIndex + 1}</div>
                  {row.map((seat, colIndex) => (
                    <div key={`${rowIndex}-${colIndex}`} className="seat">
                      {seat ? (
                        <img
                          src={
                            seat.available
                              ? selectedSeats.includes(seat.seatno)
                                ? "/images/chair-selected.png"
                                : "/images/chair-true.png"
                              : "/images/chair.png"
                          }
                          alt={seat.available ? "Available Seat" : "Unavailable Seat"}
                          className="seat-image"
                          onClick={() => toggleSeatSelection(seat)}
                        />
                      ) : (
                        <div className="empty-seat"></div>
                      )}
                    </div>
                  ))}
                </div>
              ))
            ) : (
              <p>No seats available</p>
            )}
          </div>

          {selectedSeats.length > 0 && (
            <div className="booking-actions">
              <p>Selected Seats: {selectedSeats.join(", ")}</p>
              <p>Total Price: ₹{selectedSeats.length * 100}</p>

              <input
                type="text"
                placeholder="Enter your name"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
              />
              <input
                type="tel"
                placeholder="Enter your phone number"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
              />

              <button onClick={handleBooking}>Confirm Booking</button>
            </div>
          )}
        </div>
      ) : (
        <p>No movie selected</p>
      )}
    </div>
  );
};

export default Book;