import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './css/login.css';

const Login = () => {
  const navigate = useNavigate();
  const [enteredUsername, setEnteredUsername] = useState('');
  const [enteredPassword, setEnteredPassword] = useState('');

  const handleLogin = async () => {
    try {
      const response = await fetch('http://localhost:8080/users');
      const users = await response.json();

      const loggedInUser = users.find(
        (user) =>
          user.username === enteredUsername &&
          user.password === enteredPassword
      );

      if (loggedInUser) {
        // Store user in localStorage for persistent login
        const userData = {
          username: loggedInUser.username,
          email: loggedInUser.email,
          phoneno: loggedInUser.phno,
        };

        localStorage.setItem('user', JSON.stringify(userData));

        // Redirect to home
        navigate('/home');
      } else {
        alert('Invalid username or password');
      }
    } catch (error) {
      console.error('Login failed:', error);
      alert('An error occurred while logging in');
    }
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h2>User Login</h2>
        <form>
          <div className="input-group">
            <label htmlFor="username">Username</label>
            <input
              type="text"
              id="username"
              value={enteredUsername}
              onChange={(e) => setEnteredUsername(e.target.value)}
              placeholder="Enter your username"
              required
            />
          </div>
          <div className="input-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              value={enteredPassword}
              onChange={(e) => setEnteredPassword(e.target.value)}
              placeholder="Enter your password"
              required
            />
          </div>
          <button type="button" onClick={handleLogin}>
            Login
          </button>
        </form>
        <p className="signup-link">
          Don't have an account?{' '}
          <a href="/register">Sign up</a>
        </p>
      </div>
    </div>
  );
};

export default Login;
