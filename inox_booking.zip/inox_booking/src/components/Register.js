import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import './css/register.css';

const Register = () => {
  const [form, setForm] = useState({
    name: '',
    username: '',
    password: '',
    email: '',
    phno: '',
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:8080/users', form);
      alert('User registered successfully!');
    } catch (err) {
      alert('Registration failed!');
      console.error(err);
    }
  };

  return (
    <div className="register-container">
      <div className="register-box">
        <h2>User registration</h2>
        <form onSubmit={handleRegister}>
          <div className="input-row">
            <div className="input-group">
              <label htmlFor="name">Name</label>
              <input
                name="name"
                id="name"
                placeholder="Enter your name"
                onChange={handleChange}
                value={form.name}
                required
              />
            </div>
            <div className="input-group">
              <label htmlFor="username">Username</label>
              <input
                name="username"
                id="username"
                placeholder="Choose a username"
                onChange={handleChange}
                value={form.username}
                required
              />
            </div>
          </div>
          <div className="input-group">
            <label htmlFor="password">Password</label>
            <input
              name="password"
              id="password"
              type="password"
              placeholder="Create a password"
              onChange={handleChange}
              value={form.password}
              required
            />
          </div>
          <div className="input-row">
            <div className="input-group">
              <label htmlFor="email">Email</label>
              <input
                name="email"
                id="email"
                type="email"
                placeholder="Enter your email"
                onChange={handleChange}
                value={form.email}
                required
              />
            </div>
            <div className="input-group">
              <label htmlFor="phno">Phone Number</label>
              <input
                name="phno"
                id="phno"
                placeholder="Enter your phone number"
                onChange={handleChange}
                value={form.phno}
                required
              />
            </div>
          </div>
          <button type="submit">Register</button>
        </form>
        <p className="login-link">
          Already have an account? <Link to="/login">Log in</Link>
        </p>
      </div>
    </div>
  );
};

export default Register;