import React, { useEffect, useState } from "react";
import "./css/main.css";

const Main = () => {
    const [offsetY, setOffsetY] = useState(0);

    const handleScroll = () => {
        setOffsetY(window.pageYOffset);
    };

    useEffect(() => {
        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    return (
        <div className="landing-page">
            <div
                className="first-div"
                style={{ transform: `translateY(${offsetY * 0.5}px)` }}
            >
                <div className="first-div-content">
                    <h2>BOOK YOUR <br/> TICKETS NOW</h2>
                    <a href="Login"><button>Get Started</button></a>
                </div>
            </div>
            <div className="second-div">
                <div className="content">
                    <h1>Welcome to Inox Booking</h1>
                    <p>Experience movies like never before!</p>
                </div>


                <div className="contact-div">
                    <div className="contact-content">   
                    <h1>Contact Us</h1>
                    <p>If you have any questions, feel free to reach out!</p>
                    <button className="contact-button">Contact Us</button>
                    </div>
                 
                </div>
            </div>
        </div>
    );
};

export default Main;