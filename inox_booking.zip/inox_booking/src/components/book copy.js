import React, { useEffect, useState } from "react";
import axios from "axios";
import { useLocation } from "react-router-dom";
import "./css/book.css";

const Book = () => {
  const location = useLocation();
  const { movie } = location.state || {};
  const [seats, setSeats] = useState([]);
  
  // Define the dimensions for a 4x4 matrix
  const columns = 4; // 4 seats per row
  const rows = 4; // 4 rows for a 4x4 matrix

  useEffect(() => {
    if (movie && movie.title) {
      axios
        .get(`http://localhost:8080/seats?moviename=${encodeURIComponent(movie.title)}`)
        .then((response) => {
          // Ensure availability is boolean
          const updatedSeats = response.data.map(seat => ({
            ...seat,
            available: seat.available === true || seat.available === "true"
          }));
          setSeats(updatedSeats);
          console.log("Fetched seats:", updatedSeats); // Debug: Log the fetched seats
        })
        .catch((error) => console.error("Error fetching seats:", error));
    }
  }, [movie]);

  // Convert flat seats array into a 2D array (4 rows x 4 columns)
  const maxSeats = rows * columns; // 4x4 = 16 seats
  const seatsToDisplay = seats.slice(0, maxSeats); // Take only the first 16 seats
  const seatMatrix = Array.from({ length: rows }, (_, rowIndex) => {
    return Array.from({ length: columns }, (_, colIndex) => {
      const seatIndex = rowIndex * columns + colIndex;
      return seatsToDisplay[seatIndex] || null; // Use null for empty seats
    });
  });
  console.log("Seat Matrix:", seatMatrix); // Debug: Log the 2D seat matrix

  // Generate column labels (A, B, C, D)
  const columnLabels = Array.from({ length: columns }, (_, index) =>
    String.fromCharCode(65 + index) // 65 is ASCII for 'A'
  );

  return (
    <div className="book-container">
      {movie ? (
        <div className="movie-details">
          <h1 className="movie-title">Movie Name: {movie.title}</h1>
          <p><strong>Genre:</strong> {movie.genre}</p>
          <p><strong>Showtime:</strong> {movie.stime}</p>
          <p><strong>Hall Name:</strong> {movie.hallname}</p>

          {/* Seat Matrix with Markings */}
          <h2 className="seat-heading">Available Seats</h2>
          <div className="seat-matrix-container">
            {/* Column Labels (Top) */}
            <div className="column-labels">
              <div className="row-label-placeholder"></div>
              {columnLabels.map((label, index) => (
                <div key={index} className="column-label">
                  {label}
                </div>
              ))}
            </div>

            {/* Seat Matrix with Row Labels (Left) */}
            {seatMatrix.length > 0 ? (
              seatMatrix.map((row, rowIndex) => (
                <div key={rowIndex} className="seat-row">
                  {/* Row Label (Left) */}
                  <div className="row-label">{rowIndex + 1}</div>
                  {/* Seats in the Row */}
                  {row.map((seat, colIndex) => (
                    <div key={`${rowIndex}-${colIndex}`} className="seat">
                      {seat ? (
                        <img
                          src={seat.available ? "/images/chair-true.png" : "/images/chair.png"}
                          alt={seat.available ? "Available Seat" : "Unavailable Seat"}
                          className="seat-image"
                        />
                      ) : (
                        <div className="empty-seat"></div>
                      )}
                    </div>
                  ))}
                </div>
              ))
            ) : (
              <p>No seats available</p>
            )}
          </div>

         
        </div>
      ) : (
        <p>No movie selected</p>
      )}
    </div>
  );
};

export default Book;