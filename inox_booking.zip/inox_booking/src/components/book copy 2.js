import React, { useEffect, useState } from "react";
import axios from "axios";
import { useLocation } from "react-router-dom";
import "./css/book.css";

const Book = () => {
  const location = useLocation();
  const { movie } = location.state || {}; // Extract movie details from location state
  const [seats, setSeats] = useState([]); // State to store seats data
  const [selectedSeats, setSelectedSeats] = useState([]); // State to store selected seats
  const [userName, setUserName] = useState(""); // User name input
  const [phoneNumber, setPhoneNumber] = useState(""); // User phone number input

  const columns = 4;
  const rows = 4;

  // Fetch seats data for the selected movie
  useEffect(() => {
    if (movie && movie.title) {
      axios
        .get(`http://localhost:8080/seats?moviename=${encodeURIComponent(movie.title)}`)
        .then((response) => {
          // Convert available seats to boolean if needed
          const updatedSeats = response.data.map((seat) => ({
            ...seat,
            available: seat.available === true || seat.available === "true",
          }));
          setSeats(updatedSeats);
        })
        .catch((error) => {
          console.error("Error fetching seats:", error);
          alert("Failed to load seat data.");
        });
    }
  }, [movie]);

  const maxSeats = rows * columns;
  const seatsToDisplay = seats.slice(0, maxSeats);

  // Organize seats into a matrix of rows and columns
  const seatMatrix = Array.from({ length: rows }, (_, rowIndex) => {
    return Array.from({ length: columns }, (_, colIndex) => {
      const seatIndex = rowIndex * columns + colIndex;
      return seatsToDisplay[seatIndex] || null;
    });
  });

  const columnLabels = Array.from({ length: columns }, (_, index) =>
    String.fromCharCode(65 + index) // Convert index to column label (A, B, C, D)
  );

  // Handle booking logic
  const handleBooking = () => {
    if (!userName || !phoneNumber) {
      alert("Please enter your name and phone number.");
      return;
    }

    const bookingData = {
      uname: userName,
      movie: movie.title,
      time: movie.stime,
      tprice: selectedSeats.length * 100, // Total price: ₹100 per seat
      sno: selectedSeats.join(", "), // Selected seat numbers
      pno: phoneNumber,
      date: new Date().toISOString().split("T")[0], // Current date
    };

    // First, book the tickets, then update seat availability
    axios
      .post("http://localhost:8080/bookings", bookingData)
      .then(() => {
        return Promise.all(
          selectedSeats.map((seatno) => {
            const seat = seats.find((seat) => seat.seatno === seatno);
            if (seat) {
              // Changed the URL to match the controller's endpoint
              return axios.put(`http://localhost:8080/seats/${seat.id}`, {
                ...seat,
                available: "false" // Make sure to send "false" as a string since your model uses String
              });
            }
            return null;
          })
        );
      })
      .then(() => {
        alert("Booking successful!");
        setSelectedSeats([]);
        setUserName("");
        setPhoneNumber("");

        // Refresh the seat data after booking
        return axios.get(`http://localhost:8080/seats?moviename=${encodeURIComponent(movie.title)}`);
      })
      .then((response) => {
        const updatedSeats = response.data.map((seat) => ({
          ...seat,
          available: seat.available === true || seat.available === "true",
        }));
        setSeats(updatedSeats);
      })
      .catch((err) => {
        console.error("Booking failed:", err);
        alert("Booking failed. Please try again.");
      });
  };

  // Toggle seat selection
  const toggleSeatSelection = (seat) => {
    if (!seat.available) return; // Do not allow selection if seat is unavailable

    if (selectedSeats.includes(seat.seatno)) {
      setSelectedSeats(selectedSeats.filter((seatno) => seatno !== seat.seatno)); // Deselect seat
    } else {
      setSelectedSeats([...selectedSeats, seat.seatno]); // Select seat
    }
  };

  return (
    <div className="book-container">
      {movie ? (
        <div className="movie-details">
          <h1 className="movie-title">Movie Name: {movie.title}</h1>
          <p><strong>Genre:</strong> {movie.genre}</p>
          <p><strong>Showtime:</strong> {movie.stime}</p>
          <p><strong>Hall Name:</strong> {movie.hallname}</p>

          <h2 className="seat-heading">Available Seats</h2>
          <div className="seat-matrix-container">
            <div className="column-labels">
              <div className="row-label-placeholder"></div>
              {columnLabels.map((label, index) => (
                <div key={index} className="column-label">
                  {label}
                </div>
              ))}
            </div>

            {seatMatrix.length > 0 ? (
              seatMatrix.map((row, rowIndex) => (
                <div key={rowIndex} className="seat-row">
                  <div className="row-label">{rowIndex + 1}</div>
                  {row.map((seat, colIndex) => (
                    <div key={`${rowIndex}-${colIndex}`} className="seat">
                      {seat ? (
                        <img
                          src={
                            seat.available
                              ? selectedSeats.includes(seat.seatno)
                                ? "/images/chair-selected.png"
                                : "/images/chair-true.png"
                              : "/images/chair.png"
                          }
                          alt={seat.available ? "Available Seat" : "Unavailable Seat"}
                          className="seat-image"
                          onClick={() => toggleSeatSelection(seat)}
                        />
                      ) : (
                        <div className="empty-seat"></div>
                      )}
                    </div>
                  ))}
                </div>
              ))
            ) : (
              <p>No seats available</p>
            )}
          </div>

          {selectedSeats.length > 0 && (
            <div className="booking-actions">
              <p>Selected Seats: {selectedSeats.join(", ")}</p>
              <p>Total Price: ₹{selectedSeats.length * 100}</p>

              <input
                type="text"
                placeholder="Enter your name"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
              />
              <input
                type="tel"
                placeholder="Enter your phone number"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
              />

              <button onClick={handleBooking}>Confirm Booking</button>
            </div>
          )}
        </div>
      ) : (
        <p>No movie selected</p>
      )}
    </div>
  );
};

export default Book;