import React, { useEffect, useState } from 'react';
import Navbar from './Navbar';

const Home = () => {
  const [user, setUser] = useState({});

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem('user'));
    if (storedUser) {
      setUser(storedUser);
    }
  }, []);

  return (
    <>
      <Navbar username={user.username} />
      <div style={{ padding: '2rem' }}>
        <h1>Welcome, {user.username || 'Guest'}!</h1>
        <p>Email: {user.email || 'N/A'}</p>
        <p>Phone Number: {user.phoneno || 'N/A'}</p>
      </div>
    </>
  );
};

export default Home;
