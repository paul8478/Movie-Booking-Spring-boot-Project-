package com.example.demo.controller;

import com.example.demo.model.Seat;
import com.example.demo.repository.SeatRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/seats")
public class SeatController {

    private final SeatRepository repo;

    public SeatController(SeatRepository repo) {
        this.repo = repo;
    }

    // ✅ GET seats by movie name
    @GetMapping
    public List<Seat> getSeatsByMovieName(@RequestParam String moviename) {
        return repo.findByMoviename(moviename);
    }

    // ✅ POST: create a new seat
    @PostMapping
    public Seat createSeat(@RequestBody Seat seat) {
        return repo.save(seat);
    }

    // ✅ PUT: update seat by ID
    @PutMapping("/{id}")
    public Seat updateSeat(@PathVariable Long id, @RequestBody Seat updatedSeat) {
        Seat seat = repo.findById(id).orElseThrow();

        seat.setSeatno(updatedSeat.getSeatno());
        seat.setSprice(updatedSeat.getSprice());
        seat.setAvailable(updatedSeat.getAvailable());
        seat.setHallname(updatedSeat.getHallname());
        seat.setStime(updatedSeat.getStime());
        seat.setMoviename(updatedSeat.getMoviename());
        return repo.save(seat);
    }

    // ✅ DELETE: seat by ID
    @DeleteMapping("/{id}")
    public void deleteSeat(@PathVariable Long id) {
        repo.deleteById(id);
    }
}
