package com.example.demo.controller;

import com.example.demo.model.Booking;
import com.example.demo.repository.BookingRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "http://localhost:3000") // React runs on 3000

@RestController
@RequestMapping("/bookings")
public class BookingController {

    private final BookingRepository repo;

    public BookingController(BookingRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Booking> getAllBookings() {
        return repo.findAll();
    }

    @PostMapping
    public Booking addBooking(@RequestBody Booking booking) {
        return repo.save(booking);
    }

    @PutMapping("/{id}")
    public Booking updateBooking(@PathVariable Long id, @RequestBody Booking updatedBooking) {
        Booking booking = repo.findById(id).orElseThrow();
        booking.setUname(updatedBooking.getUname());
        booking.setMovie(updatedBooking.getMovie());
        booking.setTime(updatedBooking.getTime());
        booking.setTprice(updatedBooking.getTprice());
        booking.setSno(updatedBooking.getSno());
        booking.setPno(updatedBooking.getPno());
        booking.setDate(updatedBooking.getDate());




        return repo.save(booking);
    }

    @DeleteMapping("/{id}")
    public void deleteBooking(@PathVariable Long id) {
        repo.deleteById(id);
    }
}
