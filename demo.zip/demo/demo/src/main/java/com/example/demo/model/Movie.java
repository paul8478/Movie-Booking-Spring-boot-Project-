package com.example.demo.model;

import jakarta.persistence.*;

@Entity
public class Movie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String genre;
    private int year;
    private String img;
    private String stime;
    private String hallname; // New attribute for the hall name

    // --- Getters ---
    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    public int getYear() {
        return year;
    }
    
    public String getImg() {
        return img;
    }
    
    public String getStime() {
        return stime;
    }

    public String getHallname() {
        return hallname; // Getter for hallname
    }

    // --- Setters ---
    public void setId(Long id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public void setYear(int year) {
        this.year = year;
    }
    
    public void setImg(String img) {
        this.img = img;
    }
    
    public void setStime(String stime) {
        this.stime = stime;
    }

    public void setHallname(String hallname) {
        this.hallname = hallname; // Setter for hallname
    }
}
