package com.example.demo.model;

import jakarta.persistence.*;

@Entity
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String uname;
    private String movie;
    private String time;
    private String tprice;  //tprice :- total price
    private String sno; //sno :- Seat number
    private String pno;
    private String date;




    // --- Getters ---
    public Long getId() {
        return id;
    }

    public String getUname() {
        return uname;
    }

    public String getMovie() {
        return movie;
    }    
    
    public String getTime() {
        return time;
    }
    
    public String getTprice() {
        return tprice;
    }
    
    // Seat number //
    public String getSno() {
        return sno;
    }
    public String getPno() {
        return pno;
    }
    
    public String getDate() {
        return date;
    }

    // --- Setters ---
    public void setId(Long id) {
        this.id = id;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public void setMovie(String movie) {
        this.movie = movie;
    }
    
    public void setTime(String time) {
        this.time = time;
    }
    
    public void setTprice(String tprice) {
        this.tprice = tprice;
    }

    public void setSno(String sno) {
        this.sno = sno;
    }
    
    public void setPno(String pno) {
        this.pno = pno;
    }
    
    public void setDate(String date) {
        this.date = date;
    }
    
}
