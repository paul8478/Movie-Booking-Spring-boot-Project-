package com.example.demo.model;

import jakarta.persistence.*;

@Entity
public class Seat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String seatno;
    private String sprice;
    private String available;     // Changed from boolean to String
    private String hallname;
    private String stime;
    private String moviename;     // ✅ New attribute added

    // --- Getters ---
    public Long getId() {
        return id;
    }

    public String getSeatno() {
        return seatno;
    }

    public String getSprice() {
        return sprice;
    }

    public String getAvailable() {
        return available;
    }

    public String getHallname() {
        return hallname;
    }

    public String getStime() {
        return stime;
    }

    public String getMoviename() {
        return moviename;
    }

    // --- Setters ---
    public void setId(Long id) {
        this.id = id;
    }

    public void setSeatno(String seatno) {
        this.seatno = seatno;
    }

    public void setSprice(String sprice) {
        this.sprice = sprice;
    }

    public void setAvailable(String available) {
        this.available = available;
    }

    public void setHallname(String hallname) {
        this.hallname = hallname;
    }

    public void setStime(String stime) {
        this.stime = stime;
    }

    public void setMoviename(String moviename) {
        this.moviename = moviename;
    }
}
